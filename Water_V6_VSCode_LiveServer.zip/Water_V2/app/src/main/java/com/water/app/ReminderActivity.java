package com.water.app;

import android.app.Activity;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.content.Intent;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ReminderActivity extends Activity {
    private final int bg = Color.rgb(7, 16, 32);
    private final int cyan = Color.rgb(45, 207, 240);
    private boolean handled = false;
    private Ringtone ringtone;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 26) {
            getWindow().setStatusBarColor(bg);
            getWindow().setNavigationBarColor(bg);
        }
        try {
            ringtone = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE));
            if (ringtone != null) {
                if (Build.VERSION.SDK_INT >= 28) ringtone.setLooping(true);
                ringtone.play();
            }
        } catch (Exception ignored) { }
        try {
            Vibrator v = (Vibrator)getSystemService(VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(new long[]{0,500,350,500,700}, 0));
                else v.vibrate(new long[]{0,500,350,500,700}, 0);
            }
        } catch (Exception ignored) { }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(28), dp(54), dp(28), dp(36));
        root.setBackgroundColor(bg);

        TextView eyebrow = text("LEMBRETE DO WATER", 13, cyan, true);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, dp(32));
        ep.bottomMargin = dp(28);
        root.addView(eyebrow, ep);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.water_icon);
        icon.setPadding(dp(20), dp(20), dp(20), dp(20));
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.rgb(18, 48, 76));
        circle.setStroke(dp(2), cyan);
        icon.setBackground(circle);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(142), dp(142));
        iconLp.bottomMargin = dp(32);
        root.addView(icon, iconLp);

        root.addView(text("Hora de beber água", 29, Color.WHITE, true), new LinearLayout.LayoutParams(-1, dp(58)));
        TextView sub = text("O Water está lembrando você\nde fazer uma pausa para se hidratar.", 16, Color.rgb(165,190,215), false);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, dp(76));
        subLp.bottomMargin = dp(24);
        root.addView(sub, subLp);

        TextView caller = text("CHAMADA DE HIDRATAÇÃO", 12, Color.rgb(125,154,184), true);
        LinearLayout.LayoutParams callerLp = new LinearLayout.LayoutParams(-1, dp(44));
        callerLp.bottomMargin = dp(20);
        root.addView(caller, callerLp);

        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1));

        TextView hangup = text("●   Desligar e registrar 250 ml", 17, Color.WHITE, true);
        hangup.setGravity(Gravity.CENTER);
        hangup.setBackground(pill(Color.rgb(225, 59, 75), 60));
        hangup.setElevation(dp(6));
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, dp(64));
        btnLp.bottomMargin = dp(12);
        root.addView(hangup, btnLp);
        hangup.setOnClickListener(v -> confirmAndClose());

        root.addView(text("Toque para encerrar o lembrete", 12, Color.rgb(125,154,184), false), new LinearLayout.LayoutParams(-1, dp(28)));
        setContentView(root);
    }

    private void confirmAndClose() {
        if (handled) return;
        handled = true;
        try {
            if (ringtone != null && ringtone.isPlaying()) ringtone.stop();
        } catch (Exception ignored) { }
        try {
            Vibrator v = (Vibrator)getSystemService(VIBRATOR_SERVICE);
            if (v != null) v.cancel();
        } catch (Exception ignored) { }
        WaterReminderReceiver.cancel(ReminderActivity.this);
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        i.putExtra("addWaterMl", 250);
        startActivity(i);
        finish();
    }

    @Override protected void onDestroy() {
        try { if (ringtone != null && ringtone.isPlaying()) ringtone.stop(); } catch (Exception ignored) { }
        try { Vibrator v = (Vibrator)getSystemService(VIBRATOR_SERVICE); if (v != null) v.cancel(); } catch (Exception ignored) { }
        super.onDestroy();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextColor(color); t.setTextSize(size); t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private GradientDrawable pill(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
