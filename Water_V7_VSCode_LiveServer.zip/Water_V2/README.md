# Water V4

Aplicativo de hidratação com configuração inicial, registros locais, lembretes, histórico, estatísticas e temas claro/escuro.

## Menus
- Início
- Histórico
- Estatísticas
- Configurações

## Tema
Em Configurações há duas opções: **Claro** e **Escuro**. A escolha fica salva no aparelho.

## Preview no VS Code
Abra `web/index.html` com Live Server.

## Android
O projeto Android continua em `app/` e usa o script `scripts/sync-web.sh` para copiar a versão web para os assets.


## Tela de chamada automática (Android 14+)
Ao ativar os lembretes, o app tenta abrir a tela de acesso especial de notificações em tela cheia do Android, quando necessário. Ative a permissão para permitir a experiência de chamada. O Android ou as políticas do fabricante/loja podem continuar limitando a abertura automática; nesse caso a notificação continua disponível.
