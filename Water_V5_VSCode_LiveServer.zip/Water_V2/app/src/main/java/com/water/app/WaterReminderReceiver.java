package com.water.app;

import android.app.AlarmManager;
import android.content.BroadcastReceiver;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.SystemClock;

import java.util.Calendar;

public class WaterReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "water_reminders";
    private static final int ID = 4201;
    private static final int REQUEST = 77;

    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences p = context.getSharedPreferences("water", 0);
        if (!p.getBoolean("configured", false) || !p.getBoolean("enabled", false)) return;
        if (!insideReminderWindow(p)) {
            scheduleNext(context);
            return;
        }
        show(context);
    }

    private static boolean insideReminderWindow(SharedPreferences p) {
        String start = p.getString("start", "08:00");
        String end = p.getString("end", "22:00");
        Calendar now = Calendar.getInstance();
        int current = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
        int s = toMinutes(start, 8 * 60);
        int e = toMinutes(end, 22 * 60);
        if (s == e) return true;
        if (s < e) return current >= s && current <= e;
        return current >= s || current <= e;
    }

    private static int toMinutes(String value, int fallback) {
        try {
            String[] a = value.split(":");
            return Integer.parseInt(a[0]) * 60 + Integer.parseInt(a[1]);
        } catch (Exception e) {
            return fallback;
        }
    }

    public static void schedule(Context c, int minutes, boolean enabled) {
        SharedPreferences p = c.getSharedPreferences("water", 0);
        if (!p.getBoolean("configured", false) || !enabled) {
            cancelAlarm(c);
            return;
        }
        int safeMinutes = Math.max(5, minutes);
        scheduleAfter(c, safeMinutes * 60_000L);
    }

    private static void scheduleNext(Context c) {
        SharedPreferences p = c.getSharedPreferences("water", 0);
        if (!p.getBoolean("configured", false) || !p.getBoolean("enabled", false)) return;
        int minutes = Math.max(5, p.getInt("interval", 60));
        scheduleAfter(c, minutes * 60_000L);
    }

    private static void scheduleAfter(Context c, long delay) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(c, WaterReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(c, REQUEST, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
        long when = SystemClock.elapsedRealtime() + delay;
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, when, pi);
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, when, pi);
                }
            } catch (SecurityException e) {
                am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, when, pi);
            }
        } else {
            am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, when, pi);
        }
    }

    public static void show(Context c) {
        SharedPreferences p = c.getSharedPreferences("water", 0);
        if (!p.getBoolean("configured", false) || !p.getBoolean("enabled", false)) return;

        Intent full = new Intent(c, ReminderActivity.class);
        full.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent fp = PendingIntent.getActivity(c, 99, full,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, CHANNEL)
                : new Notification.Builder(c);

        b.setSmallIcon(R.drawable.water_icon)
                .setContentTitle("💧 Hora de beber água")
                .setContentText("Arraste o botão para confirmar que você viu.")
                .setAutoCancel(false)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(fp)
                .setFullScreenIntent(fp, true);

        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(ID, b.build());
        scheduleNext(c);
    }

    private static void cancelAlarm(Context c) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(c, WaterReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(c, REQUEST, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
    }

    public static void cancel(Context c) {
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(ID);
        cancelAlarm(c);
    }
}
