package com.water.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.Context;

public class ReminderActivity extends Activity {
    private int cyan = Color.rgb(37, 199, 242);
    private int bg = Color.rgb(7, 19, 39);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        if (Build.VERSION.SDK_INT >= 26) {
            getWindow().setStatusBarColor(bg);
            getWindow().setNavigationBarColor(bg);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(30, 42, 30, 42);
        root.setBackgroundColor(bg);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.water_icon);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(116, 116);
        iconLp.bottomMargin = 20;
        root.addView(icon, iconLp);

        TextView title = text("Hora de beber água", 29, Color.WHITE, true);
        root.addView(title, new LinearLayout.LayoutParams(-1, 62));

        TextView sub = text("Seu lembrete chegou.\nDeslize o botão até o fim para confirmar.", 16,
                Color.rgb(150,190,220), false);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, 80);
        subLp.bottomMargin = 22;
        root.addView(sub, subLp);

        SlideToConfirm slider = new SlideToConfirm(this);
        root.addView(slider, new LinearLayout.LayoutParams(-1, 76));

        TextView hint = text("ARRASTE PARA CONFIRMAR", 12, cyan, true);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, 45);
        hintLp.topMargin = 12;
        root.addView(hint, hintLp);

        setContentView(root);
        slider.setOnConfirmedListener(() -> {
            WaterReminderReceiver.cancel(ReminderActivity.this);
            finish();
        });
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private class SlideToConfirm extends View {
        private float downX;
        private float knobX;
        private boolean confirmed;
        private final GradientDrawable track = rounded(Color.rgb(20, 43, 70), 38);
        private final GradientDrawable knob = rounded(cyan, 34);
        private final float density;
        private Runnable listener;

        SlideToConfirm(Context context) {
            super(context);
            density = getResources().getDisplayMetrics().density;
            setBackground(track);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setWillNotDraw(false);
        }

        void setOnConfirmedListener(Runnable r) { listener = r; }

        @Override protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            float h = getHeight();
            float knobSize = Math.min(h - 12, 64 * density);
            float left = 7;
            float right = getWidth() - knobSize - 7;
            if (knobX <= 0) knobX = left;
            knob.setBounds((int)knobX, (int)((h-knobSize)/2), (int)(knobX+knobSize), (int)((h+knobSize)/2));
            knob.draw(canvas);
            android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.WHITE);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextSize(15 * density);
            String label = confirmed ? "Confirmado ✓" : "Deslize para confirmar";
            float tw = p.measureText(label);
            canvas.drawText(label, Math.max(knobSize + 16, (getWidth()-tw)/2 + 8), h/2 + 5*density, p);
            if (!confirmed) {
                p.setColor(Color.argb(150,255,255,255));
                p.setTextSize(20*density);
                canvas.drawText("→", right - 3*density, h/2 + 7*density, p);
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float h = getHeight();
            float knobSize = Math.min(h - 12, 64 * density);
            float left = 7;
            float right = getWidth() - knobSize - 7;
            switch(e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getX();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (confirmed) return true;
                    float delta = e.getX() - downX;
                    knobX = Math.max(left, Math.min(right, knobX + delta));
                    downX = e.getX();
                    invalidate();
                    if (knobX >= right - 4) {
                        confirmed = true;
                        knobX = right;
                        invalidate();
                        if (listener != null) postDelayed(listener, 120);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!confirmed && knobX < right * 0.9f) {
                        knobX = left;
                        invalidate();
                    }
                    return true;
            }
            return true;
        }

        private GradientDrawable rounded(int color, int radius) {
            GradientDrawable d = new GradientDrawable();
            d.setColor(color);
            d.setCornerRadius(radius * density);
            return d;
        }
    }
}
