package com.water.app;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends android.app.Activity {
    private static final String CHANNEL_ID = "water_reminders";
    private static final int NOTIFICATION_PERMISSION = 40;
    private WebView web;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        createChannel();
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
    }

    void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL_ID,
                    "Lembretes de água",
                    NotificationManager.IMPORTANCE_HIGH
            );
            c.setDescription("Lembretes para beber água");
            c.enableVibration(true);
            c.setLockscreenVisibility(android.app.Notification.VISIBILITY_PUBLIC);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    public void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION) {
            SharedPreferences p = getSharedPreferences("water", 0);
            if (p.getBoolean("configured", false) && p.getBoolean("enabled", false)) {
                int minutes = p.getInt("interval", 60);
                WaterReminderReceiver.schedule(this, minutes, true);
            }
        }
    }

    public static class Bridge {
        private final Context c;
        Bridge(Context c) { this.c = c; }

        @JavascriptInterface public void requestNotificationPermission() {
            if (c instanceof MainActivity) ((MainActivity)c).requestNotificationPermission();
        }

        @JavascriptInterface public void setReminder(int minutes, boolean enabled) {
            SharedPreferences p = c.getSharedPreferences("water", 0);
            p.edit()
                    .putInt("interval", minutes)
                    .putBoolean("enabled", enabled)
                    .putBoolean("configured", true)
                    .apply();
            WaterReminderReceiver.schedule(c, minutes, enabled);
        }

        @JavascriptInterface public void testNotification() {
            SharedPreferences p = c.getSharedPreferences("water", 0);
            if (!p.getBoolean("configured", false) || !p.getBoolean("enabled", false)) return;
            WaterReminderReceiver.show(c);
        }
    }
}
