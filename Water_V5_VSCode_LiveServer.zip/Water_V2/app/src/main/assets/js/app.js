const KEY='water_v3';
const DEFAULT={configured:false,goal:2000,water:0,records:[],notify:false,interval:60,start:'08:00',end:'22:00'};
let data=JSON.parse(localStorage.getItem(KEY)||'null')||DEFAULT;
function save(){localStorage.setItem(KEY,JSON.stringify(data));render()}
function today(){return new Date().toISOString().slice(0,10)}
function dateKey(d){return new Date(d).toISOString().slice(0,10)}
function add(ml){if(!data.configured)return;data.water+=ml;data.records.push({time:new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}),ml,date:today()});save()}
function render(){
 const setup=document.getElementById('setup'), header=document.getElementById('mainHeader'), home=document.getElementById('home'), nav=document.getElementById('bottomNav');
 const configured=!!data.configured;
 setup.classList.toggle('hidden',configured); header.classList.toggle('hidden',!configured); home.classList.toggle('hidden',!configured); nav.classList.toggle('hidden',!configured);
 if(!configured)return;
 const p=Math.min(100,data.water/data.goal*100);
 document.getElementById('total').textContent=(data.water/1000).toFixed(1).replace('.',',')+' L';
 document.getElementById('percent').textContent=Math.round(p)+'%';
 document.getElementById('goalText').textContent=(data.goal/1000).toFixed(1).replace('.',',')+' L';
 document.getElementById('bar').style.width=p+'%';
 document.getElementById('todayCount').textContent=data.records.filter(r=>r.date===today()).length;
 document.getElementById('streak').textContent=calcStreak();
 document.getElementById('weekAvg').textContent=Math.round(p)+'%';
 const list=document.getElementById('todayList');
 const rs=data.records.filter(r=>r.date===today()).slice().reverse();
 list.innerHTML=rs.length?rs.map(r=>`<div class="item"><span>${r.time}</span><strong>${r.ml} ml</strong></div>`).join(''):'<div class="item"><span>Nenhum registro ainda</span><strong>💧</strong></div>';
 document.getElementById('next').textContent=data.notify?`em ${data.interval} min`:'lembretes desligados';
 renderHistory();renderStats();
}
function calcStreak(){let s=0,d=new Date();for(let i=0;i<30;i++){let k=new Date(d);k.setDate(d.getDate()-i);let day=dateKey(k);if(data.records.some(r=>r.date===day))s++;else if(i>0)break}return s}
function finishSetup(){
 data.goal=+document.getElementById('setupGoal').value;
 data.notify=document.getElementById('setupNotify').checked;
 data.configured=true;
 save();
 navigate('home');
 if(window.AndroidBridge){if(data.notify) AndroidBridge.requestNotificationPermission();AndroidBridge.setReminder(data.interval,data.notify)}
}
function navigate(screen){
 if(!data.configured)return;
 ['home','historyScreen','statsScreen','settings'].forEach(id=>{const el=document.getElementById(id);if(el)el.classList.toggle('hidden',id!==screen)});
 document.querySelectorAll('.bottom-nav button').forEach(btn=>btn.classList.toggle('active',btn.dataset.screen===screen));
 if(screen==='historyScreen')renderHistory();
 if(screen==='statsScreen')renderStats();
 window.scrollTo({top:0,behavior:'smooth'});
}
function openSettings(){navigate('settings')}
function closeSettings(){navigate('home')}
function saveSettings(){
 if(!data.configured)return;
 const wasEnabled=data.notify;
 data.notify=document.getElementById('notify').checked;
 data.interval=+document.getElementById('interval').value;
 data.goal=+document.getElementById('goal').value;
 data.start=document.getElementById('start').value;
 data.end=document.getElementById('end').value;
 save();
 if(window.AndroidBridge){if(data.notify&&!wasEnabled)AndroidBridge.requestNotificationPermission();AndroidBridge.setReminder(data.interval,data.notify)}
}
function setTheme(theme){
 document.body.classList.toggle('light',theme==='light');
 localStorage.waterTheme=theme;
 updateThemeButtons();
}
function updateThemeButtons(){
 const light=localStorage.waterTheme==='light';
 document.getElementById('themeLight')?.classList.toggle('active',light);
 document.getElementById('themeDark')?.classList.toggle('active',!light);
 const meta=document.querySelector('meta[name="theme-color"]');if(meta)meta.content=light?'#f4f9fd':'#071327';
}
function syncSettingsUI(){
 document.getElementById('notify').checked=data.notify;
 document.getElementById('interval').value=data.interval;
 document.getElementById('goal').value=data.goal;
 document.getElementById('start').value=data.start;
 document.getElementById('end').value=data.end;
 updateThemeButtons();
}
function testReminder(){
 if(!data.configured){alert('Finalize a configuração do Water primeiro.');return}
 if(!data.notify){alert('Ative as notificações nas Configurações primeiro.');return}
 if(window.AndroidBridge)AndroidBridge.testNotification();
 else if('Notification'in window){Notification.requestPermission().then(p=>{if(p==='granted')new Notification('Hora de beber água',{body:'Abra o Water para confirmar o lembrete.'})})}
 else alert('No APK, o lembrete será exibido pelo sistema.')
}
function renderHistory(){
 const el=document.getElementById('fullHistoryList');if(!el)return;
 const rows=data.records.slice().reverse();
 el.innerHTML=rows.length?rows.map(r=>`<div class="historyrow"><span>${r.date} · ${r.time}</span><strong>${r.ml} ml</strong></div>`).join(''):'<p style="color:var(--muted)">Nenhum registro de água ainda.</p>';
}
function renderStats(){
 if(!data.configured)return;
 const todayMl=data.records.filter(r=>r.date===today()).reduce((a,r)=>a+r.ml,0);
 const p=Math.min(100,todayMl/data.goal*100);
 const days=[];for(let i=6;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);days.push({key:dateKey(d),label:d.toLocaleDateString('pt-BR',{weekday:'short'}).replace('.','').slice(0,3),ml:0})}
 days.forEach(d=>d.ml=data.records.filter(r=>r.date===d.key).reduce((a,r)=>a+r.ml,0));
 const avg=days.reduce((a,d)=>a+d.ml,0)/7;
 const max=data.records.reduce((m,r)=>Math.max(m,r.ml),0);
 document.getElementById('statToday').textContent=(todayMl/1000).toFixed(1).replace('.',',')+' L';
 document.getElementById('statTodayPct').textContent=Math.round(p)+'% da meta';
 document.getElementById('statAvg7').textContent=(avg/1000).toFixed(1).replace('.',',')+' L';
 document.getElementById('statMax').textContent=max+' ml';
 document.getElementById('statStreak').textContent=calcStreak()+' dias';
 document.getElementById('weekChart').innerHTML=days.map(d=>{const pct=Math.min(100,d.ml/data.goal*100);return `<div class="daybar"><div class="bartrack"><i class="fill" style="height:${pct}%"></i></div><b>${d.ml?Math.round(d.ml/100)/10+'L':'0'}</b><span>${d.label}</span></div>`}).join('');
}
function openHistory(){navigate('historyScreen')}
function closeModal(){document.getElementById('modal').classList.add('hidden')}
if(localStorage.waterTheme==='light')document.body.classList.add('light');
render();
if(data.configured){syncSettingsUI();navigate('home')}else updateThemeButtons();
