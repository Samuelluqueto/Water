const KEY='water_v3';
const DEFAULT={configured:false,goal:2000,water:0,records:[],notify:false,interval:60,start:'08:00',end:'22:00'};
let data=JSON.parse(localStorage.getItem(KEY)||'null')||DEFAULT;
function save(){localStorage.setItem(KEY,JSON.stringify(data));render()}
function today(){return new Date().toISOString().slice(0,10)}
function add(ml){if(!data.configured)return;data.water+=ml;data.records.push({time:new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}),ml,date:today()});save()}
function render(){
 const setup=document.getElementById('setup'), header=document.getElementById('mainHeader'), home=document.getElementById('home');
 const configured=!!data.configured;
 setup.classList.toggle('hidden',configured); header.classList.toggle('hidden',!configured); home.classList.toggle('hidden',!configured);
 if(!configured)return;
 const p=Math.min(100,data.water/data.goal*100);
 document.getElementById('total').textContent=(data.water/1000).toFixed(1).replace('.',',')+' L';
 document.getElementById('percent').textContent=Math.round(p)+'%';
 document.getElementById('goalText').textContent=(data.goal/1000).toFixed(1).replace('.',',')+' L';
 document.getElementById('bar').style.width=p+'%';
 document.getElementById('todayCount').textContent=data.records.filter(r=>r.date===today()).length;
 document.getElementById('streak').textContent=calcStreak();
 document.getElementById('weekAvg').textContent=Math.round(p)+'%';
 const list=document.getElementById('todayList');
 const rs=data.records.filter(r=>r.date===today()).slice().reverse();
 list.innerHTML=rs.length?rs.map(r=>`<div class="item"><span>${r.time}</span><strong>${r.ml} ml</strong></div>`).join(''):'<div class="item"><span>Nenhum registro ainda</span><strong>💧</strong></div>';
 document.getElementById('next').textContent=data.notify?`em ${data.interval} min`:'lembretes desligados';
}
function calcStreak(){let s=0,d=new Date();for(let i=0;i<30;i++){let k=new Date(d);k.setDate(d.getDate()-i);let day=k.toISOString().slice(0,10);if(data.records.some(r=>r.date===day))s++;else if(i>0)break}return s}
function finishSetup(){
 data.goal=+document.getElementById('setupGoal').value;
 data.notify=document.getElementById('setupNotify').checked;
 data.configured=true;
 save();
 if(window.AndroidBridge){
   if(data.notify) AndroidBridge.requestNotificationPermission();
   AndroidBridge.setReminder(data.interval,data.notify);
 }
}
function openSettings(){if(!data.configured)return;document.getElementById('settings').classList.remove('hidden');document.getElementById('notify').checked=data.notify;document.getElementById('interval').value=data.interval;document.getElementById('goal').value=data.goal;document.getElementById('start').value=data.start;document.getElementById('end').value=data.end;document.getElementById('dark').checked=!document.body.classList.contains('light')}
function closeSettings(){document.getElementById('settings').classList.add('hidden')}
function saveSettings(){
 if(!data.configured)return;
 const wasEnabled=data.notify;
 data.notify=document.getElementById('notify').checked;
 data.interval=+document.getElementById('interval').value;
 data.goal=+document.getElementById('goal').value;
 data.start=document.getElementById('start').value;
 data.end=document.getElementById('end').value;
 save();
 if(window.AndroidBridge){
   if(data.notify && !wasEnabled) AndroidBridge.requestNotificationPermission();
   AndroidBridge.setReminder(data.interval,data.notify);
 }
}
function testReminder(){
 if(!data.configured){alert('Finalize a configuração do Water primeiro.');return}
 if(!data.notify){alert('Ative as notificações nas Configurações primeiro.');return}
 if(window.AndroidBridge) AndroidBridge.testNotification();
 else if('Notification'in window){Notification.requestPermission().then(p=>{if(p==='granted')new Notification('Hora de beber água',{body:'Abra o Water para confirmar o lembrete.'})})}
 else alert('No APK, o lembrete será exibido pelo sistema.')
}
function openHistory(){const rows=data.records.slice().reverse().map(r=>`<div class="historyrow"><span>${r.date} · ${r.time}</span><strong>${r.ml} ml</strong></div>`).join('')||'<p>Nenhum registro.</p>';document.getElementById('modalContent').innerHTML='<h2>Histórico</h2>'+rows;document.getElementById('modal').classList.remove('hidden')}
function closeModal(){document.getElementById('modal').classList.add('hidden')}
if(localStorage.waterTheme==='light')document.body.classList.add('light');
render();
