package com.water.app;

import android.app.Activity;
import android.app.NotificationManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class ReminderActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        getWindow().setStatusBarColor(Color.rgb(7,19,39));
        getWindow().setNavigationBarColor(Color.rgb(7,19,39));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(42, 50, 42, 50);
        root.setBackgroundColor(Color.rgb(7,19,39));

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.water_icon);
        icon.setPadding(22,22,22,22);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(130,130);
        iconLp.bottomMargin = 24;
        root.addView(icon, iconLp);

        TextView title = new TextView(this);
        title.setText("Hora de beber água");
        title.setTextColor(Color.WHITE);
        title.setTextSize(29);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, 75));

        TextView sub = new TextView(this);
        sub.setText("Seu lembrete chegou. Deslize até o fim para confirmar que você viu.");
        sub.setTextColor(Color.rgb(150,190,220));
        sub.setTextSize(16);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub, new LinearLayout.LayoutParams(-1, 85));

        SeekBar seek = new SeekBar(this);
        seek.setMax(100);
        seek.setProgress(0);
        LinearLayout.LayoutParams seekLp = new LinearLayout.LayoutParams(-1, 70);
        seekLp.topMargin = 22;
        root.addView(seek, seekLp);

        TextView hint = new TextView(this);
        hint.setText("ARRASTE PARA CONFIRMAR  →");
        hint.setTextColor(Color.rgb(37,199,242));
        hint.setTextSize(14);
        hint.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        hint.setGravity(Gravity.CENTER);
        root.addView(hint, new LinearLayout.LayoutParams(-1, 55));

        setContentView(root);

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean f) {
                if (p >= 95) {
                    WaterReminderReceiver.cancel(ReminderActivity.this);
                    finish();
                }
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
    }
}
