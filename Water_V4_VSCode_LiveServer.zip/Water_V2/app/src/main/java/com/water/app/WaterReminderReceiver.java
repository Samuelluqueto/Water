package com.water.app;

import android.app.AlarmManager;
import android.content.BroadcastReceiver;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.SystemClock;

public class WaterReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "water_reminders";
    private static final int ID = 4201;

    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences p = context.getSharedPreferences("water", 0);
        if (!p.getBoolean("configured", false) || !p.getBoolean("enabled", false)) return;
        show(context);
    }

    public static void schedule(Context c, int minutes, boolean enabled) {
        SharedPreferences p = c.getSharedPreferences("water", 0);
        if (!p.getBoolean("configured", false) || !enabled) {
            AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            Intent i = new Intent(c, WaterReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(c, 77, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi);
            return;
        }

        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(c, WaterReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(c, 77, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
        long delay = Math.max(5, minutes) * 60_000L;
        am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + delay, pi);
    }

    public static void show(Context c) {
        SharedPreferences p = c.getSharedPreferences("water", 0);
        if (!p.getBoolean("configured", false) || !p.getBoolean("enabled", false)) return;

        Intent full = new Intent(c, ReminderActivity.class);
        full.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent fp = PendingIntent.getActivity(c, 99, full, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, CHANNEL)
                : new Notification.Builder(c);

        b.setSmallIcon(R.drawable.water_icon)
                .setContentTitle("Hora de beber água")
                .setContentText("Arraste para confirmar que você viu o lembrete.")
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(fp);

        // Full-screen behavior is attempted for the requested call-like experience.
        b.setFullScreenIntent(fp, true);

        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(ID, b.build());

        int minutes = p.getInt("interval", 60);
        schedule(c, minutes, true);
    }

    public static void cancel(Context c) {
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(ID);
    }
}
